![](https://github.com/JJYing/Nurburgring-Corners/blob/master/assets/screenshot.jpg?raw=true)

# Reference
- [Nurburgring Corner Names](https://oversteer48.com/nurburgring-corner-names/)
- [NRing.info](https://nring.info/nurburgring-nordschleife-corners/)
- [Nürburgring Corner Names Explained](https://www.youtube.com/watch?v=-lCR1_cDqTg)
- [【干货】纽北每一个弯的名字？](https://www.bilibili.com/video/BV1NntCe4ETM/)
