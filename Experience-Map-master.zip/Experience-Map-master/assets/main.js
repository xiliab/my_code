let rootURL = document.baseURI
var root = document.querySelector(':root')
const body = document.querySelector('body');
if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
  root.classList.add('dark')
}


var d = new Vue({
  el: '#app',
  data: {
    p: 0,
    w: 1000,
    h: 1004,
    mX: 0,
    mY: 0,
    lang: lang,
    showModal: false,
    showAllCornerNames: false,
    darkMode: window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches,
    showCorner: false,
    showSection: false,
    showBridges: false,
    showSections: false,
    currentCorner: null,
    scrollDistance: 0,
    cornerStart: 0,
    cornerEnd: 0,
    sectionStart: 0,
    sectionEnd: 0,
    sections: [
      /*{
        st: 0.0,
        ed: 0.143,
        x: 0.1,
        y: 0.1,
        h: "c",
        v: "m",
        ch: "\u8d5b\u6bb51",
        en: "Section 1",
        de: "Abschnitt 1"
      },
      {
        st: 0.857,
        ed: 1.0,
        x: 0.394,
        y: 0.568,
        h: "c",
        v: "m",
        ch: "\u8d5b\u6bb57",
        en: "Section 7",
        de: "Abschnitt 7"
      }*/
    ],

    bridges: [
      /*{
        stx: 0.1,
        sty: 0.1,
        edx: 0.115,
        edy: 0.12,
        pt: 0.015,
        x: 0.108,
        y: 0.11,
        h: "c",
        v: "m",
        ch: "\u6865\u68811"
      },
      {
        stx: 0.1,
        sty: 0.367,
        edx: 0.115,
        edy: 0.387,
        pt: 0.957,
        x: 0.108,
        y: 0.377,
        h: "c",
        v: "m",
        ch: "\u6865\u68813"
      }*/
    ],
    corners: [
      {
        st: 0.0,
        ed: 0.01,
        x: 0.051,
        y: 0.349,
        h: "c",
        v: "m",
        ch: "2012毕业",
        en: "广工大学",
        de: "广州",
        more: "2012年，我从广东工业大学材料与能源学院毕业了。",
        imgs: [
          {
            src: "https://cdn.jsdelivr.net/gh/xiliab/my-images@main/Certificate_of_Graduation.jpg",
            author: "lilongxiao",
            desc: "毕业证书。"
          },
          {
            src: "https://cdn.jsdelivr.net/gh/xiliab/my-images@main/Certificate_of_Bachelors_Degree.jpg",
            author: "lilongxiao",
            desc: "学士学位证书。"
          },
        ],
      },
      {
        st: 0.01,
        ed: 0.15,
        x: 0.178,
        y: 0.40,
        h: "c",
        v: "m",
        ch: "机械设计师",
        en: "子律节能公司",
        de: "广州",
        more: "通过仪器实地建模获取数据，在UG中导入数据后进行设计，然后完成生产出图，跟进产品生产确保质量，获取数据进行优化迭代。",
        imgs: [
          {
            src: "https://cdn.jsdelivr.net/gh/xiliab/my-images@main/3a31b41f_fb6c_4c76.jpg",
            author: "lilongxiao",
            desc: "暖通机房的设计施工。"
          },
          {
            src: "https://cdn.jsdelivr.net/gh/xiliab/my-images@main/cb4bd329_3ee8_4046.jpg",
            author: "lilongxiao",
            desc: "自动化养殖设备的设计生产。"
          },
        ],
      },
      {
        st: 0.15,
        ed: 0.22,
        x: 0.316,
        y: 0.794,
        h: "c",
        v: "m",
        ch: "UI设计师",
        en: "朗岸文化公司",
        de: "广州",
        more: "负责产品界面视觉设计、组件规范制定与多端适配，并与产品和开发团队协作推动设计高效落地与持续优化。",
        imgs: [
          {
            src: "https://cdn.jsdelivr.net/gh/xiliab/my-images@main/Say_hello.jpg",
            author: "lilongxiao",
            desc: "转行成为UI&UX设计师。"
          },
          {
            type: "video",
            src: "https://cdn.jsdelivr.net/gh/xiliab/my_video@main/%E6%A8%A1%E5%9E%8B%E6%89%93%E5%8D%B0%E6%BC%94%E7%A4%BA.mp4",
            thumb: "https://cdn.jsdelivr.net/gh/xiliab/my-images@main/Model_Library_Empty_State.jpg", // 你的视频封面
            desc: "这是为某品牌3D打印机设计打印界面的交互演示视频。"
          }
        ],
      },
      {
        st: 0.22,
        ed: 0.3,
        x: 0.33,
        y: 0.864,
        h: "c",
        v: "m",
        ch: "高级UI设计师",
        en: "兆晶科技公司",
        de: "广州",
        more: "负责用户体验设计及视觉设计工作，完成产品流程规划与视觉设计方案，提升用户满意度；负责新风机设备手机端控制界面的设计，提升用户交互体验和产品易用性。",
        imgs: [
          {
            src: "https://cdn.jsdelivr.net/gh/xiliab/my-images@main/ad_air_machine.jpg",
            author: "lilongxiao",
            desc: "公司设计制造销售的产品类别之一。"
          },
          {
            src: "https://cdn.jsdelivr.net/gh/xiliab/my-images@main/Zhaojin_logo_22_09_56.jpg",
            author: "lilongxiao",
            desc: "当时为兆晶科技设计的logo。"
          },
        ],
      },
      {
        st: 0.3,
        ed: 0.365,
        x: 0.67,
        y: 0.97,
        h: "c",
        v: "m",
        ch: "智能家居-新风",
        en: "兆晶科技公司",
        de: "广州",
        more: "负责用户体验设计及视觉设计工作，完成产品流程规划与视觉设计方案，提升用户满意度；负责新风机设备手机端控制界面的设计，提升用户交互体验和产品易用性。",
        imgs: [
          {
            src: "flugplatz-1.jpg",
            url: "https://smallblogv8.blogspot.com/2015/08/the-nurburgring-nordschleife-is-finally.html",
            author: "Small Blog V8",
          },
        ],
      },
      {
        st: 0.365,
        ed: 0.4,
        x: 0.55,
        y: 0.75,
        h: "c",
        v: "m",
        ch: "设计经理",
        en: "金蓝盟公司",
        de: "广州",
        more: "主导产品的前期战略定位、需求分析，提供高质量的交互方案和界面视觉；负责团队的管理工作及新人的培训，确保团队设计产出的质量和进度。",
        imgs: [
          {
            src: "sabine-3.jpg",
            url: "https://themotorsporthubni.com/2024/03/16/sabine-schmitz-queen-of-the-nurburgring/",
            author: "Miguel Bosch",
          },
          {
            src: "sabine-1.jpg",
            url: "https://www.motorbox.com/auto/sport/news/motorsport-piange-sabine-schmitz-regina-nurburgring-nordschleife",
            author: "motorbox",
          },
        ],
      },
      {
        st: 0.4,
        ed: 0.435,
        x: 0.45,
        y: 0.635,
        h: "c",
        v: "m",
        ch: "企业学习--商学院",
        en: "金蓝盟公司",
        de: "广州",
        more: "主导产品的前期战略定位、需求分析，提供高质量的交互方案和界面视觉；负责团队的管理工作及新人的培训，确保团队设计产出的质量和进度。",
        imgs: [
          {
            src: "quiddelbacher-2.jpg",
            author: "dh-ontour.de",
            url: "https://www.dh-ontour.de/nuerburgring/runde/eine_runde04.htm",
          },
        ],
      },
      {
        st: 0.435,
        ed: 0.51,
        x: 0.7,
        y: 0.665,
        h: "c",
        v: "m",
        ch: "业务线设计负责人",
        en: "三维家公司",
        de: "广州",
        more: "带领10人左右的UED团队，负责公司平台产品部的设计工作提升团队设计效率和质量；与业务部门紧密合作，优化产品设计流程和用户体验；推动团队的跨职能协作，提升整体设计质量和交付效果。",
        imgs: [
          {
            src: "flugplatz-1.jpg",
            url: "https://smallblogv8.blogspot.com/2015/08/the-nurburgring-nordschleife-is-finally.html",
            author: "Small Blog V8",
          },
        ],
      },
      {
        st: 0.51,
        ed: 0.58,
        x: 0.76,
        y: 0.44,
        h: "c",
        v: "m",
        ch: "家装-三维家",
        en: "三维家公司",
        de: "广州",
        more: "带领10人左右的UED团队，负责公司平台产品部的设计工作提升团队设计效率和质量；与业务部门紧密合作，优化产品设计流程和用户体验；推动团队的跨职能协作，提升整体设计质量和交付效果。",
        imgs: [
          {
            src: "hatzenbach-1.jpg",
            author: "Gruppe C GmbH",
            url: "https://www.24h-rennen.de/camping-hatzenbach/",
          },
          {
            src: "hatzenbach-3.jpg",
            url: "https://racetours.co.uk/",
            author: "RaceTours",
          },
        ],
      },
      {
        st: 0.58,
        ed: 0.72,
        x: 0.84,
        y: 0.3,
        h: "c",
        v: "m",
        ch: "设计负责人",
        en: "银光科技公司",
        de: "广州",
        more: "主导公司产品线的用户体验设计工作，涵盖客户端、手机端后台三大用户端的交互设计，建立组件规范提升产品一致性和用户体验；完成企业微信赋能企业营销平台设计，助力超百家企业客户实现业务提升，获得市场广泛认可；设计公司品牌形象，实现品牌形象从用户感知到视觉表达的统一与提升。",
        imgs: [
          {
            src: "flugplatz-1.jpg",
            url: "https://smallblogv8.blogspot.com/2015/08/the-nurburgring-nordschleife-is-finally.html",
            author: "Small Blog V8",
          },
        ],
      },
      {
        st: 0.72,
        ed: 0.8,
        x: 0.78,
        y: 0.04,
        h: "c",
        v: "m",
        ch: "全渠道私域-微聊",
        en: "银光科技公司",
        de: "广州",
        more: "主导公司产品线的用户体验设计工作，涵盖客户端、手机端后台三大用户端的交互设计，建立组件规范提升产品一致性和用户体验；完成企业微信赋能企业营销平台设计，助力超百家企业客户实现业务提升，获得市场广泛认可；设计公司品牌形象，实现品牌形象从用户感知到视觉表达的统一与提升。",
        imgs: [
          {
            src: "quiddelbacher-2.jpg",
            author: "dh-ontour.de",
            url: "https://www.dh-ontour.de/nuerburgring/runde/eine_runde04.htm",
          },
        ],
      },
      {
        st: 0.8,
        ed: 0.88,
        x: 0.56,
        y: 0.18,
        h: "c",
        v: "m",
        ch: "SCRM-金桥",
        en: "银光科技公司",
        de: "广州",
        more: "主导公司产品线的用户体验设计工作，涵盖客户端、手机端后台三大用户端的交互设计，建立组件规范提升产品一致性和用户体验；完成企业微信赋能企业营销平台设计，助力超百家企业客户实现业务提升，获得市场广泛认可；设计公司品牌形象，实现品牌形象从用户感知到视觉表达的统一与提升。",
        imgs: [
          {
            src: "fox-1.jpg",
            url: "https://zh.wikipedia.org/zh-cn/File:Nordschleife_Fuchsroehre_800x453.jpg",
            author: "BUICK REGAL",
          },
        ],
      },
      {
        st: 0.88,
        ed: 0.94,
        x: 0.33,
        y: 0.06,
        h: "c",
        v: "m",
        ch: "录播-栏目系统",
        en: "银光科技公司",
        de: "广州",
        more: "其实是一个挺长的组合弯，包含了两快五慢总共七个弯道",
        imgs: [
          {
            src: "hatzenbach-1.jpg",
            author: "Gruppe C GmbH",
            url: "https://www.24h-rennen.de/camping-hatzenbach/",
          },
          {
            src: "hatzenbach-3.jpg",
            url: "https://racetours.co.uk/",
            author: "RaceTours",
          },
        ],
      },
      {
        st: 0.94,
        ed: 0.999,
        x: 0.18,
        y: 0.22,
        h: "c",
        v: "m",
        ch: "人生在继续，体验永不停",
        en: "Point 28",
        de: "Punkt 28",
        more: "很多人会把这一段和接下来的飞机场搞混...",
        imgs: [
          {
            src: "quiddelbacher-2.jpg",
            author: "dh-ontour.de",
            url: "https://www.dh-ontour.de/nuerburgring/runde/eine_runde04.htm",
          },
        ],
      },
      
    ],
    aboutContent: "网页设计 & 开发：LiLongXiao</a><br/><br/><strong>联系我:</strong><br/>· <a target='_blank' href='https://oversteer48.com/nurburgring-corner-names/'>电话：15018471860</a><br/>· <a target='_blank' href='https://nring.info/nurburgring-nordschleife-corners/'>邮箱：xiliab@icloud.com</a><br/>· <a target='_blank' href='https://www.youtube.com/watch?v=-lCR1_cDqTg'>Nürburgring Corner Names Explained</a><br/>· 键盘车神教教主视频：<a target='_blank' href='https://www.bilibili.com/video/BV1NntCe4ETM/'>纽北每一个弯的名字？</a><br/><br/><strong>致谢:</strong><br/>· <a target='_blank' href='https://github.com/JJYing/Nurburgring-Map'>在GitHub无私放源码的jjying</a>",
    modalContent: "",
    modalType: "text"
  },
  methods: {
    innerModal: function (e) {
      e.stopPropagation()
    },
    toggleLang() {
      this.lang = this.lang === 'en' ? 'cn' : 'en'
    },
    toggleDarkMode() {
      this.darkMode = !this.darkMode
      if (this.darkMode == true) {
        root.classList.add("dark")
      }
      else {
        root.classList.remove("dark")
      }
    },
    setP: function (percentage) {
      this.p = percentage
      window.scrollTo(0, (body.scrollHeight - window.innerHeight) * percentage);
      updateScrollDistance()
    },
    openModal: function (type, media = null) {
  this.modalType = type
  if (type == 'text') {
    this.modalContent = this.aboutContent
  }
  // 图片
  if (type == 'image' || (media && media.type === 'image')) {
    this.modalContent = "<img src='" + media.src + "' style='max-width:100%;max-height:60vh;'/>";
    // 加一段介绍
    if (media.desc) {
      this.modalContent += `<div class="modal-desc">${media.desc}</div>`;
    }
    if (media.url) {
      this.modalContent += "<div class='source-in-modal'>@<a href='" + media.url + "' target='_blank'>" + media.author + "</a></div>"
    }
  }
  // 视频
  if (type == 'video' || (media && media.type === 'video')) {
    this.modalContent = `
      <video controls autoplay style="max-width:100%;max-height:60vh;background:#000;">
        <source src="${media.src}" type="video/mp4">
        您的浏览器不支持视频播放。
      </video>
    `;
    // 视频介绍文字
    if (media.desc) {
      this.modalContent += `<div class="modal-desc">${media.desc}</div>`;
    }
    if (media.url) {
      this.modalContent += "<div class='source-in-modal'>@<a href='" + media.url + "' target='_blank'>" + media.author + "</a></div>"
    }
  }
  this.showModal = true
}

  }
})


document.addEventListener('scroll', function (e) {
  if (window.scrollY > 2) {
    document.body.classList.add("scrolled")
  }
  else {
    document.body.classList.remove("scrolled")
  }
});


function updateScrollDistance() {
  d.showCorner = false
  d.showSection = false
  d.showCornerDesc = false
  d.currentCorner = null
  let progress = window.scrollY / (body.scrollHeight - window.innerHeight)
  if (progress > 1) {
    progress = 1
  }
  body.style.setProperty('--p', progress)
  d.p = progress
  d.corners.forEach((corner, i) => {
    if (progress > corner.st && progress < corner.ed) {
      d.showCorner = true
      d.cornerStart = corner.st
      d.cornerEnd = corner.ed
      d.currentCorner = corner
    }
  })
  d.sections.forEach((section, i) => {
    if (progress > section.st && progress < section.ed) {
      d.showSection = true
      d.sectionStart = section.st
      d.sectionEnd = section.ed
    }
  })
}

function updatePageHeight() {
  if (window.innerHeight < window.innerWidth) {
    body.classList.remove("vertical")
    body.classList.add("horizontal")
  }
  else {
    body.classList.remove("horizontal")
    body.classList.add("vertical")
  }
}

window.addEventListener('scroll', updateScrollDistance)
window.addEventListener('resize', function () {
  updateScrollDistance()
  updatePageHeight()
})

updateScrollDistance()
updatePageHeight()

window.addEventListener("keyup", function (e) {
  if (e.key === "Escape") {
    d.showModal = false
  }
})

document.querySelector('.experience-map > .inner').addEventListener('mousemove', function (event) {
  const innerRect = this.getBoundingClientRect();
  d.mX = (event.clientX - innerRect.left) / innerRect.width
  d.mY = (event.clientY - innerRect.top) / innerRect.height
});
