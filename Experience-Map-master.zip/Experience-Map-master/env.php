<?PHP
$cssDir = "assets";
$jsDir = "assets";
$imgDir = "assets";
$assetsDir = "assets";
?>
